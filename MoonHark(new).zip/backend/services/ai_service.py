import os
from google import genai
from openai import OpenAI
from backend.routers.admin import app_state

async def generate_response(messages: list, model_type: str = "gpt-4o"):
    api_key = app_state.api_key
    provider = app_state.provider

    if not api_key:
        return "API 키가 설정되지 않았습니다. 관리자 페이지에서 연결해주세요."

    try:
        if provider == "gpt":
            # User requested GPT-5 support. If they type 'gpt-5' in their key or settings (future), we try to use it.
            # Since 'gpt-5' is not yet public in 2024 (real time), we might fallback or try strictly.
            # Assuming user has access or we just pass the string.
            # We default to gpt-4o unless specified otherwise.
            target_model = "gpt-5" if "gpt-5" in model_type or model_type == "gpt-5" else "gpt-4o"
            
            client = OpenAI(api_key=api_key)
            response = client.chat.completions.create(
                model=target_model, 
                messages=messages
            )
            return response.choices[0].message.content

        elif provider == "gemini":
            # Using new google-genai library
            # User requested "Gemini 3" support.
            # We will try to map "gemini" to the latest available or what the user asked.
            # If "gemini-3" is requested, we use it. For now, we default to "gemini-2.0-flash-exp" or simply "gemini-1.5-pro" if 3 fails.
            # But let's try to honor the request structure.
            
            target_model = "gemini-2.5-flash" # Default fallback
            # In a real scenario, we might let the user choose the model name in AdminPanel.
            
            from google.genai import types
            
            client = genai.Client(api_key=api_key)
            
            # Convert messages to Gemini structured format
            contents = []
            for msg in messages:
                if msg["role"] == "system":
                    # System prompt is usually passed as 'system_instruction' config or just first user part in some APIs.
                    # The google-genai library supports config=types.GenerateContentConfig(system_instruction=...)
                    # We'll extract system prompt if possible, or prepended as user text if not strict.
                    # But correctly, let's try to capture system prompt separately.
                    pass 
                else:
                    role = "user" if msg["role"] == "user" else "model"
                    contents.append(types.Content(role=role, parts=[types.Part.from_text(text=msg['content'])]))
            
            # Extract system prompt
            system_instruction = next((msg['content'] for msg in messages if msg['role'] == "system"), None)

            response = client.models.generate_content(
                model=target_model,
                contents=contents,
                config=types.GenerateContentConfig(
                    system_instruction=system_instruction
                ) if system_instruction else None
            )
            return response.text

        else:
            return "알 수 없는 제공자입니다."

    except Exception as e:
        return f"AI 응답 생성 중 오류 발생: {str(e)}"
