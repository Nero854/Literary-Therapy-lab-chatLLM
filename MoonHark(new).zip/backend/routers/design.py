from fastapi import APIRouter, UploadFile, File, Form, HTTPException
from typing import List, Optional
from pydantic import BaseModel
import json
from backend.services.file_service import save_upload_file, extract_text_from_file

router = APIRouter(prefix="/api/design", tags=["design"])

# In-memory storage for design data
class DesignState:
    positive_prompt: str = ""
    negative_prompt: str = ""
    strict_prompt: str = ""
    story_text: str = ""
    file_contents: str = ""
    empathy_level: int = 1
    interpretation_level: int = 1
    intervention_level: int = 1
    activity_level: int = 1

design_state = DesignState()

@router.post("/save")
async def save_design(
    positive_prompt: str = Form(""),
    negative_prompt: str = Form(""),
    strict_prompt: str = Form(""),
    story_text: str = Form(""),
    empathy_level: int = Form(1),
    interpretation_level: int = Form(1),
    intervention_level: int = Form(1),
    activity_level: int = Form(1),
    files: List[UploadFile] = File(default=[])
):
    try:
        design_state.positive_prompt = positive_prompt
        design_state.negative_prompt = negative_prompt
        design_state.strict_prompt = strict_prompt
        design_state.story_text = story_text
        design_state.empathy_level = empathy_level
        design_state.interpretation_level = interpretation_level
        design_state.intervention_level = intervention_level
        design_state.activity_level = activity_level
        
        # Process files
        attached_text = ""
        for file in files:
            file_path = await save_upload_file(file)
            text = extract_text_from_file(file_path)
            attached_text += f"\n--- 첨부파일: {file.filename} ---\n{text}\n"
        
        design_state.file_contents = attached_text
        
        return {"status": "success", "message": "설계가 저장되었습니다."}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"저장 중 오류 발생: {str(e)}")

@router.delete("/reset")
async def reset_design():
    global design_state
    design_state = DesignState()
    return {"status": "success", "message": "초기화되었습니다."}

@router.get("/current")
async def get_current_design():
    return design_state.__dict__
