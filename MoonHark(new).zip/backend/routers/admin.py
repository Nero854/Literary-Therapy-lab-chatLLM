from fastapi import APIRouter, HTTPException, Depends
from pydantic import BaseModel

router = APIRouter(prefix="/api/admin", tags=["admin"])

class LoginRequest(BaseModel):
    password: str

class ApiKeyRequest(BaseModel):
    api_key: str
    provider: str  # "gemini" or "gpt"

# In-memory storage for simplicity, as per requirements (local app)
class AppState:
    api_key: str = None
    provider: str = None

app_state = AppState()

@router.post("/login")
async def login(request: LoginRequest):
    # Password for admin login
    if request.password == "1234":
        return {"status": "success", "message": "Login successful"}
    else:
        raise HTTPException(status_code=401, detail="Invalid password")

@router.post("/verify-key")
async def verify_key(request: ApiKeyRequest):
    # Here we would ideally test the key against the API
    # For now, we will store it and assume it's valid if it looks like a key
    if not request.api_key:
        raise HTTPException(status_code=400, detail="API key is empty")
    
    app_state.api_key = request.api_key
    app_state.provider = request.provider
    
    # Mock validation for now
    return {"status": "success", "message": "API key connected"}

@router.post("/analysis-login")
async def analysis_login(request: LoginRequest):
    # Password for analysis part
    if request.password == "1234":
        return {"status": "success", "message": "Analysis Login successful"}
    else:
        raise HTTPException(status_code=401, detail="Invalid password")
