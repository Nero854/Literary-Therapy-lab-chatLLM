from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
import os
import json
import datetime
from backend.services.ai_service import generate_response

router = APIRouter(prefix="/api/analysis", tags=["analysis"])

LOG_DIR = "consultation_data"
EXPORT_DIR = "consultation_export"

os.makedirs(LOG_DIR, exist_ok=True)
os.makedirs(EXPORT_DIR, exist_ok=True)

@router.get("/list")
async def list_logs():
    files = [f for f in os.listdir(LOG_DIR) if f.endswith(".json")]
    files.sort(reverse=True)
    return files

@router.get("/load/{filename}")
async def load_log(filename: str):
    file_path = os.path.join(LOG_DIR, filename)
    if not os.path.exists(file_path):
        raise HTTPException(status_code=404, detail="파일을 찾을 수 없습니다.")
    
    with open(file_path, 'r', encoding='utf-8') as f:
        data = json.load(f)
    return data

class InsightRequest(BaseModel):
    chat_history: list
    design_data: dict

@router.post("/insight")
async def generate_insight(request: InsightRequest):
    # Prompt for the Interpretation Agent
    system_prompt = """
당신은 문학치료 상담 결과를 분석하는 해석 전용 에이전트입니다.
상담 로그를 분석하고 심리상담과 예술치료, 문학치료 관점에서 다음을 분석하세요:
1. 내담자의 주요 정서 및 태도
2. 이야기 창작 과정에서의 특이사항
3. 주목할 만한 점 및 우려되는 점
4. 상담가를 위한 제언

반드시 한국어로 작성하세요.
    """
    
    # Format chat history for the prompt
    formatted_history = ""
    for msg in request.chat_history:
        formatted_history += f"[{msg['role']}]: {msg['content']}\n"

    messages = [
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": f"다음 상담 기록을 분석해주세요:\n{formatted_history}"}
    ]
    
    insight = await generate_response(messages)
    return {"insight": insight}

class ExportRequest(BaseModel):
    filename: str
    log_data: dict
    insight: str

@router.post("/export")
async def export_data(request: ExportRequest):
    timestamp = datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
    base_name = f"{timestamp}_상담내보내기"
    
    # 1. Log Export
    log_content = json.dumps(request.log_data, ensure_ascii=False, indent=2)
    log_path = os.path.join(EXPORT_DIR, f"{base_name}_log.txt")
    with open(log_path, "w", encoding="utf-8") as f:
        f.write(log_content)
        
    # 2. Insight Export
    insight_path = os.path.join(EXPORT_DIR, f"{base_name}_insight.txt")
    with open(insight_path, "w", encoding="utf-8") as f:
        f.write(request.insight)
        
    # 3. Chat Transcript
    chat_path = os.path.join(EXPORT_DIR, f"{base_name}_chat.txt")
    history = request.log_data.get("history", [])
    transcript = ""
    for msg in history:
        transcript += f"{msg['role']} ({msg.get('timestamp', '')}): {msg['content']}\n"
        
    with open(chat_path, "w", encoding="utf-8") as f:
        f.write(transcript)
        
    return {"status": "success", "message": f"파일 내보내기 완료: {EXPORT_DIR}"}

class AnalysisChatRequest(BaseModel):
    message: str
    history: list # context
    log_context: str # summary or log to keep in mind

@router.post("/chat")
async def analysis_chat(request: AnalysisChatRequest):
    system_prompt = f"""
당신은 문학치료 상담 결과를 분석하고 상담가와 논의하는 해석 에이전트입니다.
제공된 상담 로그를 바탕으로 전문가의 질문에 한국어로 답변하세요.
[상담 맥락]
{request.log_context}
    """
    
    messages = [{"role": "system", "content": system_prompt}]
    messages.extend(request.history)
    messages.append({"role": "user", "content": request.message})
    
    response = await generate_response(messages)
    return {"response": response}

