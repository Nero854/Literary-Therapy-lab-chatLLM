from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from backend.routers import admin, design, chat, analysis
import os

app = FastAPI()

# Allow CORS for frontend dev server
origins = [
    "http://localhost:5173",
    "http://localhost:3000",
]

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

from fastapi.staticfiles import StaticFiles

app.include_router(admin.router)
app.include_router(design.router)
app.include_router(chat.router)
app.include_router(analysis.router)

# Mount static files (Frontend Build)
# We assume the frontend is built into ../frontend/dist
frontend_dir = os.path.join(os.path.dirname(__file__), "..", "frontend", "dist")
if os.path.exists(frontend_dir):
    app.mount("/", StaticFiles(directory=frontend_dir, html=True), name="static")

@app.get("/api/health")
async def health_check():
    return {"status": "ok"}
