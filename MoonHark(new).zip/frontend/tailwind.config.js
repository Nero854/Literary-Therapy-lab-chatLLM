/** @type {import('tailwindcss').Config} */
export default {
    content: [
        "./index.html",
        "./src/**/*.{js,ts,jsx,tsx}",
    ],
    theme: {
        extend: {
            colors: {
                'premium-dark': '#1a1a1a',
                'premium-card': '#2d2d2d',
                'premium-accent': '#646cff',
            }
        },
    },
    plugins: [],
}
