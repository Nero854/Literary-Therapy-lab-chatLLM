import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';

const AdminPanel = () => {
    const [apiKey, setApiKey] = useState('');
    const [provider, setProvider] = useState('gpt'); // or 'gemini'
    const [status, setStatus] = useState('');
    const navigate = useNavigate();

    const handleConnect = async () => {
        try {
            await axios.post('http://localhost:8000/api/admin/verify-key', {
                api_key: apiKey,
                provider: provider
            });
            setStatus('연결 완료! 시작하기 버튼이 활성화되었습니다.');
        } catch (err) {
            setStatus('오류: 연결할 수 없습니다. 키를 확인하세요.');
        }
    };

    return (
        <div className="flex flex-col items-center justify-center min-h-[80vh]">
            <div className="glass-panel p-8 w-full max-w-2xl">
                <h2 className="text-2xl font-bold mb-6 text-premium-accent">API 키 관리</h2>

                <div className="space-y-6">
                    <div className="flex gap-4">
                        <select
                            value={provider}
                            onChange={(e) => setProvider(e.target.value)}
                            className="bg-premium-card border border-gray-600 rounded p-2"
                        >
                            <option value="gpt">OpenAI (GPT)</option>
                            <option value="gemini">Google (Gemini)</option>
                        </select>
                        <input
                            type="password"
                            className="input-field flex-1"
                            placeholder="API Key 입력"
                            value={apiKey}
                            onChange={(e) => setApiKey(e.target.value)}
                        />
                        <button onClick={handleConnect} className="btn-primary">
                            연결 / 새로고침
                        </button>
                    </div>

                    <div className="bg-black/30 p-4 rounded h-32 overflow-y-auto font-mono text-sm">
                        <p className="text-gray-400">Log Output:</p>
                        <p className={status.includes('오류') ? 'text-red-400' : 'text-green-400'}>
                            {status}
                        </p>
                    </div>

                    <button
                        disabled={!status.includes('연결 완료')}
                        onClick={() => navigate('/design')}
                        className={`w-full py-4 text-xl font-bold rounded transition-colors ${status.includes('연결 완료')
                                ? 'bg-premium-accent hover:bg-blue-600 text-white'
                                : 'bg-gray-700 text-gray-400 cursor-not-allowed'
                            }`}
                    >
                        시작하기
                    </button>
                </div>
            </div>
        </div>
    );
};

export default AdminPanel;
