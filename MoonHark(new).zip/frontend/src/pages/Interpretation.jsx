import { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';

const Interpretation = () => {
    const navigate = useNavigate();
    const [logs, setLogs] = useState([]);
    const [selectedLog, setSelectedLog] = useState(null);
    const [logContent, setLogContent] = useState(null);
    const [insight, setInsight] = useState('');
    const [chatHistory, setChatHistory] = useState([]);
    const [input, setInput] = useState('');
    const [loading, setLoading] = useState(false);
    const [viewState, setViewState] = useState('list'); // list | analysis

    // Modal ref for logs
    const modalRef = useRef(null);

    useEffect(() => {
        fetchLogs();
    }, []);

    const fetchLogs = async () => {
        try {
            const res = await axios.get('http://localhost:8000/api/analysis/list');
            setLogs(res.data);
        } catch (err) {
            alert("로그 목록을 불러오지 못했습니다.");
        }
    };

    const handleLoadLog = async (filename) => {
        try {
            setViewState('loading');
            const res = await axios.get(`http://localhost:8000/api/analysis/load/${filename}`);
            setLogContent(res.data);
            setSelectedLog(filename);

            // Generate Insight
            const insightRes = await axios.post('http://localhost:8000/api/analysis/insight', {
                chat_history: res.data.history || [],
                design_data: res.data.design || {}
            });
            setInsight(insightRes.data.insight);

            // Set Chat Ready
            setChatHistory([{ role: 'assistant', content: '사전설계 상담 준비 완료. 전문가님, 분석에 대해 의견을 주시거나 질문해주세요.' }]);
            setViewState('analysis');
        } catch (err) {
            alert("로드 실패: " + err.message);
            setViewState('list');
        }
    };

    const handleSend = async (e) => {
        e.preventDefault();
        if (!input.trim()) return;

        const userMsg = input;
        setInput('');
        setChatHistory(prev => [...prev, { role: 'user', content: userMsg }]);
        setLoading(true);

        try {
            const res = await axios.post('http://localhost:8000/api/analysis/chat', {
                message: userMsg,
                history: chatHistory,
                log_context: JSON.stringify(logContent)
            });
            setChatHistory(prev => [...prev, { role: 'assistant', content: res.data.response }]);
        } catch (err) {
            alert("응답 실패");
        } finally {
            setLoading(false);
        }
    };

    const handleExport = async () => {
        try {
            const res = await axios.post('http://localhost:8000/api/analysis/export', {
                filename: selectedLog,
                log_data: logContent,
                insight: insight
            });
            alert(res.data.message);
        } catch (err) {
            alert("내보내기 실패");
        }
    };

    const handleExit = () => {
        if (!window.confirm("종료하시겠습니까? (내보내지 않은 데이터는 삭제될 수 있습니다)")) return;
        // Reset and go back to list or home? Prompt says "Reset and Exit". "Exit button... initialized and exit". 
        // Here we just go back to login or list.
        setViewState('list');
        setLogContent(null);
        setInsight('');
        setChatHistory([]);
    };

    if (viewState === 'list') {
        return (
            <div className="flex flex-col items-center justify-center min-h-[80vh]">
                <div className="glass-panel p-8 w-full max-w-4xl">
                    <h2 className="text-2xl font-bold mb-6 text-premium-accent">상담 아카이브</h2>
                    <div className="grid gap-4 max-h-[60vh] overflow-y-auto">
                        {logs.length === 0 ? <p className="text-gray-400">저장된 상담 기록이 없습니다.</p> : null}
                        {logs.map(log => (
                            <div key={log} className="flex justify-between items-center bg-gray-800 p-4 rounded hover:bg-gray-700 transition">
                                <span>{log}</span>
                                <button onClick={() => handleLoadLog(log)} className="btn-primary py-1 px-4 text-sm">열기</button>
                            </div>
                        ))}
                    </div>
                    <button onClick={() => navigate('/')} className="mt-8 text-gray-400 hover:text-white">메인으로 돌아가기</button>
                </div>
            </div>
        );
    }

    if (viewState === 'loading') {
        return <div className="text-center mt-20 text-xl animate-pulse">데이터 분석 중입니다...</div>
    }

    return (
        <div className="h-[calc(100vh-2rem)] flex flex-col">
            <div className="flex justify-between items-center mb-4">
                <h1 className="text-xl font-bold">해석 및 분석: {selectedLog}</h1>
                <div className="flex gap-4">
                    <button onClick={() => document.getElementById('archive-modal').showModal()} className="px-4 py-2 bg-gray-700 rounded">아카이브</button>
                    <button onClick={handleExport} className="px-4 py-2 bg-blue-600 rounded">내보내기</button>
                    <button onClick={handleExit} className="px-4 py-2 bg-red-800 rounded">종료하기</button>
                </div>
            </div>

            <div className="flex-1 grid grid-cols-3 gap-4 min-h-0">
                {/* Left: Log View */}
                <div className="glass-panel flex flex-col p-4 overflow-hidden">
                    <h3 className="font-bold mb-2 text-yellow-400">상담 로그 (JSON)</h3>
                    <div className="flex-1 overflow-y-auto bg-black/30 p-2 rounded text-xs font-mono custom-scrollbar">
                        <pre>{JSON.stringify(logContent, null, 2)}</pre>
                    </div>
                </div>

                {/* Middle: Chat View */}
                <div className="glass-panel flex flex-col p-4 overflow-hidden relative">
                    <h3 className="font-bold mb-2 text-premium-accent">메인 채팅 (전문가 상담)</h3>
                    <div className="flex-1 overflow-y-auto space-y-4 mb-4 custom-scrollbar">
                        {chatHistory.map((msg, idx) => (
                            <div key={idx} className={`p-3 rounded-lg ${msg.role === 'assistant' ? 'bg-gray-700' : 'bg-blue-600 ml-auto max-w-[80%]'}`}>
                                {msg.content}
                            </div>
                        ))}
                        {loading && <div className="text-gray-500 text-sm">생각 중...</div>}
                    </div>
                    <form onSubmit={handleSend} className="flex gap-2">
                        <input value={input} onChange={e => setInput(e.target.value)} className="input-field flex-1" placeholder="분석에 대해 질의..." disabled={loading} />
                        <button type="submit" className="btn-primary" disabled={loading}>전송</button>
                    </form>
                </div>

                {/* Right: Insight View */}
                <div className="glass-panel flex flex-col p-4 overflow-hidden">
                    <h3 className="font-bold mb-2 text-purple-400">인사이트 (자동 분석)</h3>
                    <div className="flex-1 overflow-y-auto bg-black/30 p-4 rounded whitespace-pre-wrap leading-relaxed custom-scrollbar">
                        {insight}
                    </div>
                </div>
            </div>

            {/* Simple Archive Modal Overlay */}
            <dialog id="archive-modal" className="bg-transparent backdrop:bg-black/50 p-0 rounded-xl" onClick={(e) => {
                if (e.target.id === 'archive-modal') e.target.close();
            }}>
                <div className="glass-panel p-8 w-[500px] max-h-[60vh] overflow-y-auto text-white">
                    <div className="flex justify-between mb-4">
                        <h3 className="text-xl font-bold">아카이브 (닫기: ESC 또는 배경 클릭)</h3>
                        <button onClick={() => document.getElementById('archive-modal').close()}>X</button>
                    </div>
                    {logs.map(log => (
                        <div key={log} className="flex justify-between items-center bg-gray-700 p-2 mb-2 rounded">
                            <span>{log}</span>
                            <button onClick={() => { handleLoadLog(log); document.getElementById('archive-modal').close(); }} className="text-sm bg-blue-600 px-2 py-1 rounded">열기</button>
                        </div>
                    ))}
                </div>
            </dialog>
        </div>
    );
};

export default Interpretation;
