import { useState, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';

const PreDesign = () => {
    const navigate = useNavigate();
    const fileInputRef = useRef(null);

    const [formData, setFormData] = useState({
        positive_prompt: '',
        negative_prompt: '',
        strict_prompt: '',
        story_text: '',
        empathy_level: 1,
        interpretation_level: 1,
        intervention_level: 1,
        activity_level: 1,
    });
    const [files, setFiles] = useState([]);
    const [message, setMessage] = useState('');

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData(prev => ({ ...prev, [name]: value }));
    };

    const handleSliderChange = (e) => {
        const { name, value } = e.target;
        setFormData(prev => ({ ...prev, [name]: parseInt(value) }));
    };

    const handleFileChange = (e) => {
        const selected = Array.from(e.target.files);
        if (files.length + selected.length > 3) {
            alert("파일은 최대 3개까지만 첨부 가능합니다.");
            return;
        }
        setFiles(prev => [...prev, ...selected]);
    };

    const removeFile = (index) => {
        setFiles(prev => prev.filter((_, i) => i !== index));
    };

    const handleSave = async () => {
        const data = new FormData();
        Object.keys(formData).forEach(key => {
            data.append(key, formData[key]);
        });
        files.forEach(file => {
            data.append('files', file);
        });

        try {
            await axios.post('http://localhost:8000/api/design/save', data);
            setMessage('저장 완료되었습니다.');
        } catch (err) {
            setMessage('저장 실패: ' + err.message);
        }
    };

    const handleReset = async () => {
        if (!window.confirm("모든 데이터를 초기화하시겠습니까?")) return;
        try {
            await axios.delete('http://localhost:8000/api/design/reset');
            setFormData({
                positive_prompt: '', negative_prompt: '', strict_prompt: '', story_text: '',
                empathy_level: 1, interpretation_level: 1, intervention_level: 1, activity_level: 1
            });
            setFiles([]);
            setMessage('초기화되었습니다.');
        } catch (err) {
            setMessage('초기화 실패');
        }
    };

    return (
        <div className="min-h-screen pb-20">
            <h1 className="text-3xl font-bold mb-8 text-premium-accent">사전 설계</h1>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                {/* Left Column: Prompts & Story */}
                <div className="space-y-6">
                    <div className="glass-panel p-6">
                        <h3 className="text-xl font-bold mb-4">프롬프트 설정</h3>
                        <div className="space-y-4">
                            <textarea name="positive_prompt" value={formData.positive_prompt} onChange={handleChange} placeholder="긍정적 프롬프트" className="input-field h-60 resize-none" />
                            <textarea name="negative_prompt" value={formData.negative_prompt} onChange={handleChange} placeholder="부정적 프롬프트" className="input-field h-60 resize-none" />
                            <input name="strict_prompt" value={formData.strict_prompt} onChange={handleChange} placeholder="절대 준수 사항" className="input-field" />
                        </div>
                    </div>

                    <div className="glass-panel p-6">
                        <h3 className="text-xl font-bold mb-4">이야기 박스 & 파일 첨부</h3>
                        <textarea
                            name="story_text"
                            value={formData.story_text}
                            onChange={handleChange}
                            placeholder="구전문화 이야기 전문 입력"
                            className="input-field h-40 resize-none mb-4"
                        />

                        <div className="border border-dashed border-gray-500 rounded p-4 text-center cursor-pointer hover:bg-white/5 transition"
                            onClick={() => fileInputRef.current.click()}>
                            <p className="text-gray-400">PDF, Excel, Text 파일 드래그 또는 클릭 (최대 3개)</p>
                            <input
                                type="file"
                                multiple
                                hidden
                                ref={fileInputRef}
                                onChange={handleFileChange}
                                accept=".pdf,.xlsx,.xls,.txt"
                            />
                        </div>
                        <div className="mt-2 space-y-2">
                            {files.map((f, i) => (
                                <div key={i} className="flex justify-between items-center bg-gray-800 p-2 rounded">
                                    <span className="text-sm truncate">{f.name}</span>
                                    <button onClick={(e) => { e.stopPropagation(); removeFile(i); }} className="text-red-400">X</button>
                                </div>
                            ))}
                        </div>
                    </div>
                </div>

                {/* Right Column: Sliders */}
                <div className="space-y-6">
                    <div className="glass-panel p-6">
                        <h3 className="text-xl font-bold mb-6">하이퍼파라미터 설정</h3>
                        {[
                            { label: '공감 정도', name: 'empathy_level', desc: '좌: 형식적 / 우: 적극적 공감' },
                            { label: '해석 수준', name: 'interpretation_level', desc: '좌: 드라이 / 우: 상세 평가' },
                            { label: '개입 수준', name: 'intervention_level', desc: '좌: 무개입 / 우: 민감 반응' },
                            { label: '적극성 수준', name: 'activity_level', desc: '좌: 수동 / 우: 능동적 사건 생성' }
                        ].map((item) => (
                            <div key={item.name} className="mb-8">
                                <div className="flex justify-between mb-2">
                                    <label className="font-bold">{item.label}</label>
                                    <span className="text-premium-accent">{formData[item.name]}단계</span>
                                </div>
                                <input
                                    type="range"
                                    min="1"
                                    max="3"
                                    step="1"
                                    name={item.name}
                                    value={formData[item.name]}
                                    onChange={handleSliderChange}
                                    className="w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer"
                                />
                                <p className="text-xs text-gray-400 mt-1">{item.desc}</p>
                            </div>
                        ))}
                    </div>
                </div>
            </div>

            {/* Footer Actions */}
            <div className="fixed bottom-0 left-0 right-0 bg-premium-dark/90 backdrop-blur border-t border-gray-700 p-4">
                <div className="max-w-7xl mx-auto flex justify-between items-center">
                    <div className="text-green-400 font-bold">{message}</div>
                    <div className="flex gap-4">
                        <button onClick={handleReset} className="px-6 py-2 rounded bg-gray-600 hover:bg-gray-500">초기화</button>
                        <button onClick={handleSave} className="px-6 py-2 rounded bg-blue-600 hover:bg-blue-500">저장</button>
                        <button
                            onClick={() => {
                                if (!message.includes('저장')) { alert('저장을 먼저 해주세요.'); return; }
                                navigate('/operation');
                            }}
                            className="px-8 py-2 rounded bg-premium-accent hover:bg-purple-600 font-bold shadow-lg shadow-purple-500/30"
                        >
                            실행
                        </button>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default PreDesign;
