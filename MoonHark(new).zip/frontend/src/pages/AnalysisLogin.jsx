import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';

const AnalysisLogin = () => {
    const [password, setPassword] = useState('');
    const [error, setError] = useState('');
    const navigate = useNavigate();

    const handleLogin = async (e) => {
        e.preventDefault();
        try {
            await axios.post('http://localhost:8000/api/admin/analysis-login', { password });
            navigate('/analysis');
        } catch (err) {
            setError('비밀번호가 일치하지 않습니다.');
        }
    };

    return (
        <div className="flex flex-col items-center justify-center min-h-[80vh]">
            <div className="glass-panel p-8 w-full max-w-md text-center">
                <div className="mb-8 text-gray-300">
                    상담이 종료되었습니다. 감사합니다.
                </div>
                <h1 className="text-3xl font-bold mb-6 text-premium-accent">해석부 로그인</h1>
                <form onSubmit={handleLogin} className="space-y-4">
                    <input
                        type="password"
                        placeholder="비밀번호 입력"
                        className="input-field text-center text-lg"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                    />
                    {error && <p className="text-red-400 text-sm">{error}</p>}
                    <button type="submit" className="btn-primary w-full">
                        로그인
                    </button>
                </form>
            </div>
        </div>
    );
};

export default AnalysisLogin;
