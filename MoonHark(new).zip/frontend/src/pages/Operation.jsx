import { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';

const Operation = () => {
    const navigate = useNavigate();
    const bottomRef = useRef(null);

    const [story, setStory] = useState('');
    const [history, setHistory] = useState([]);
    const [input, setInput] = useState('');
    const [loading, setLoading] = useState(false);
    const [completeEnabled, setCompleteEnabled] = useState(false);

    // Initialize
    useEffect(() => {
        const initChat = async () => {
            try {
                // Get story text for left panel
                const designRes = await axios.get('http://localhost:8000/api/design/current');
                setStory(designRes.data.story_text || "(이야기가 없습니다)");

                // Start chat session
                const startRes = await axios.post('http://localhost:8000/api/chat/start');
                setHistory([{ role: 'assistant', content: startRes.data.message }]);
            } catch (err) {
                alert("세션 시작 실패");
            }
        };
        initChat();
    }, []);

    // Auto scroll
    useEffect(() => {
        bottomRef.current?.scrollIntoView({ behavior: 'smooth' });

        // Check for completion trigger in last message
        if (history.length > 0) {
            const lastMsg = history[history.length - 1];
            if (lastMsg.role === 'assistant' && lastMsg.content.includes("상담완료 버튼을 눌러주세요")) {
                setCompleteEnabled(true);
            }
        }
    }, [history]);

    const handleSend = async (e) => {
        e.preventDefault();
        if (!input.trim()) return;

        const userMsg = input;
        setInput('');
        setHistory(prev => [...prev, { role: 'user', content: userMsg }]);
        setLoading(true);

        try {
            const res = await axios.post('http://localhost:8000/api/chat/send', { message: userMsg });
            let aiText = res.data.response;
            if (aiText.includes('[[COMPLETION]]')) {
                aiText = aiText.replace('[[COMPLETION]]', '').trim();
                setCompleteEnabled(true);
            }

            setHistory(prev => [...prev, { role: 'assistant', content: aiText }]);

            if (!res.data.is_active) {
                alert('상담이 종료되었습니다.');
                setCompleteEnabled(true); // Enable completion if session forced end
            }
        } catch (err) {
            setHistory(prev => [...prev, { role: 'assistant', content: "오류가 발생했습니다." }]);
        } finally {
            setLoading(false);
        }
    };

    const handleEnd = async (isComplete) => {
        if (!window.confirm(isComplete ? "상담을 완료하시겠습니까? (완료 후 해석부로 이동합니다)" : "상담을 중단하고 종료하시겠습니까? (저장 후 초기화면으로 이동)")) return;

        try {
            await axios.post('http://localhost:8000/api/chat/end');

            if (isComplete) {
                navigate('/analysis-login');
            } else {
                navigate('/');
            }
        } catch (err) {
            console.error("End session failed", err);
            // Fallback navigation
            if (isComplete) navigate('/analysis-login');
            else navigate('/');
        }
    };

    return (
        <div className="flex h-[calc(100vh-2rem)] gap-4">
            {/* Left: Story View */}
            <div className="w-1/3 glass-panel p-6 flex flex-col">
                <h2 className="text-xl font-bold mb-4 text-premium-accent">이야기 자료</h2>
                <div className="flex-1 overflow-y-auto whitespace-pre-wrap text-gray-300 leading-relaxed custom-scrollbar">
                    {story}
                </div>
            </div>

            {/* Right: Chat View */}
            <div className="w-2/3 glass-panel flex flex-col relative">
                <div className="flex-1 overflow-y-auto p-6 space-y-4 custom-scrollbar">
                    {history.map((msg, idx) => (
                        <div key={idx} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                            <div className={`max-w-[80%] rounded-lg p-3 ${msg.role === 'user'
                                ? 'bg-blue-600 text-white rounded-br-none'
                                : 'bg-gray-700 text-gray-200 rounded-bl-none'
                                }`}>
                                {msg.content}
                            </div>
                        </div>
                    ))}
                    {loading && <div className="text-gray-400 text-sm animate-pulse">응답 생성 중...</div>}
                    <div ref={bottomRef} />
                </div>

                {/* Input Area */}
                <div className="p-4 border-t border-gray-700 bg-black/20">
                    <form onSubmit={handleSend} className="flex gap-2">
                        <input
                            value={input}
                            onChange={(e) => setInput(e.target.value)}
                            className="input-field flex-1"
                            placeholder="메시지를 입력하세요..."
                            disabled={loading || completeEnabled}
                        />
                        <button type="submit" disabled={loading || completeEnabled} className="btn-primary">전송</button>
                    </form>
                </div>

                {/* Footer Buttons */}
                <div className="p-4 flex justify-between border-t border-gray-700 bg-black/40 rounded-b-xl">
                    <button
                        onClick={() => handleEnd(false)}
                        className="px-4 py-2 bg-red-900/50 hover:bg-red-800 text-red-200 rounded transition"
                    >
                        상담종료 (저장 후 종료)
                    </button>
                    <button
                        onClick={() => handleEnd(true)}
                        disabled={!completeEnabled}
                        className={`px-4 py-2 rounded transition font-bold ${completeEnabled
                            ? 'bg-green-600 hover:bg-green-500 text-white shadow-lg shadow-green-500/30'
                            : 'bg-gray-800 text-gray-500 cursor-not-allowed'
                            }`}
                    >
                        상담완료
                    </button>
                </div>
            </div>
        </div>
    );
};

export default Operation;
