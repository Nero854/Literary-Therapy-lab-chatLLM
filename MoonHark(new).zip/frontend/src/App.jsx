import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import AdminLogin from './pages/AdminLogin';
import AdminPanel from './pages/AdminPanel';
import PreDesign from './pages/PreDesign';
import Operation from './pages/Operation';
import AnalysisLogin from './pages/AnalysisLogin';
import Interpretation from './pages/Interpretation';

function App() {
  return (
    <Router>
      <div className="min-h-screen bg-premium-dark text-white p-4">
        <div className="max-w-7xl mx-auto">
          <Routes>
            <Route path="/" element={<AdminLogin />} />
            <Route path="/admin" element={<AdminPanel />} />
            <Route path="/design" element={<PreDesign />} />
            <Route path="/operation" element={<Operation />} />
            <Route path="/analysis-login" element={<AnalysisLogin />} />
            <Route path="/analysis" element={<Interpretation />} />
            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
        </div>
      </div>
    </Router>
  );
}

export default App;
