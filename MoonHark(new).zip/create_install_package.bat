@echo off
chcp 65001 > nul
echo [MoonHark] Creating Installation Package...
echo ==============================================

set TARGET_DIR=install

:: 1. Frontend Build
echo [1/5] Building Frontend...
if exist frontend\dist (
    echo Found existing dist. Cleaning...
    rmdir /s /q frontend\dist
)
cd frontend
call npm install
call npm run build
if errorlevel 1 (
    echo [ERROR] Frontend build failed. Exiting.
    cd ..
    pause
    exit /b
)
cd ..

:: 2. Prepare Target Directory
echo [2/5] Preparing 'install' directory...
if exist %TARGET_DIR% (
    echo Cleaning existing install folder...
    rmdir /s /q %TARGET_DIR%
)
mkdir %TARGET_DIR%

:: 3. Copy Backend & Requirements
echo [3/5] Copying application files...
mkdir %TARGET_DIR%\backend
xcopy backend %TARGET_DIR%\backend /E /I /Y
exclude_pycache.txt
copy requirements.txt %TARGET_DIR%\

:: 4. Copy Frontend Build
echo [4/5] Copying frontend build...
mkdir %TARGET_DIR%\frontend\dist
xcopy frontend\dist %TARGET_DIR%\frontend\dist /E /I /Y

:: 5. Copy Client Scripts
echo [5/5] Creating launcher scripts...
copy client_setup.bat %TARGET_DIR%\setup_moonhark.bat
copy client_run.bat %TARGET_DIR%\run_moonhark.bat

echo.
echo ==============================================
echo [SUCCESS] Package created in '%TARGET_DIR%' folder.
echo.
echo instructions:
echo 1. Copy the '%TARGET_DIR%' folder to the target computer.
echo 2. Run 'setup_moonhark.bat' once to install.
echo 3. Run 'run_moonhark.bat' to start.
echo ==============================================
pause
