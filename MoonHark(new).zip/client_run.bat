@echo off
chcp 65001 > nul
echo [MoonHark] Starting Application...
echo ==========================================

if not exist venv (
    echo [ERROR] Virtual environment not found.
    echo Please run 'setup_moonhark.bat' first.
    pause
    exit /b
)

echo Activating environment...
call venv\Scripts\activate

echo Starting Server...
echo The browser will open automatically at http://localhost:8000
echo (Press Ctrl+C in this window to stop)
echo.

start http://localhost:8000
uvicorn backend.main:app --host 0.0.0.0 --port 8000 --workers 1

pause
