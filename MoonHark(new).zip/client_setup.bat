@echo off
chcp 65001 > nul
echo [MoonHark] Installation Setup
echo ==========================================
echo This script will set up the environment for MoonHark on this computer.
echo.

:: Check Python
python --version > nul 2>&1
if errorlevel 1 (
    echo [ERROR] Python is not found. Please install Python 3.10 or higher.
    echo Download: https://www.python.org/downloads/
    pause
    exit /b
)

:: Create Virtual Environment
if not exist venv (
    echo [1/2] Creating virtual environment (venv)...
    python -m venv venv
) else (
    echo [1/2] Virtual environment already exists.
)

:: Install Dependencies
echo [2/2] Installing dependencies...
call venv\Scripts\activate
pip install -r requirements.txt

echo.
echo [SUCCESS] Installation Complete!
echo You can now run 'run_moonhark.bat' to start the application.
echo.
pause
