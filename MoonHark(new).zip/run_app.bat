@echo off
chcp 65001 > nul
echo [MoonHark] Setting up MoonHark Environment...

cd /d %~dp0

:: Check Python
python --version > nul 2>&1
if errorlevel 1 (
    echo [ERROR] Python is not installed or not in PATH. Please install Python 3.10+.
    pause
    exit /b
)

:: Virtual Env
if not exist venv (
    echo [MoonHark] Creating virtual environment...
    python -m venv venv
)

echo [MoonHark] Activating venv...
call venv\Scripts\activate

:: Dependencies
echo [MoonHark] Installing backend dependencies...
pip install -r requirements.txt

:: Frontend Build
echo [MoonHark] Building frontend...
cd frontend
call npm install
call npm run build
cd ..

:: Launch
echo [MoonHark] Starting Application...
echo [MoonHark] Please wait while the server starts...
echo [MoonHark] The browser will open automatically at http://localhost:8000
start http://localhost:8000
uvicorn backend.main:app --host 0.0.0.0 --port 8000 --workers 1

pause
